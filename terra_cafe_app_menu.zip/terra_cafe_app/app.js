const KEY='cafeManagerV1';
const defaultData={
 shopName:"Моя кав'ярня",
 products:[
  {id:1,name:"Еспресо 30 мл",price:35,category:"Класична кава",emoji:"☕"},
  {id:2,name:"Допіо 50–60 мл",price:45,category:"Класична кава",emoji:"☕"},
  {id:3,name:"Американо 200 мл",price:45,category:"Класична кава",emoji:"☕"},
  {id:4,name:"Американо 300 мл",price:50,category:"Класична кава",emoji:"☕"},
  {id:5,name:"Американо з молоком 250 мл",price:50,category:"Класична кава",emoji:"🥛"},
  {id:6,name:"Американо з молоком 300 мл",price:55,category:"Класична кава",emoji:"🥛"},
  {id:7,name:"Еспресо макіато 40–60 мл",price:40,category:"Класична кава",emoji:"☕"},
  {id:8,name:"Капучино 200 мл",price:55,category:"Кава з молоком",emoji:"🥛"},
  {id:9,name:"Капучино 300 мл",price:65,category:"Кава з молоком",emoji:"🥛"},
  {id:10,name:"Лате 300 мл",price:65,category:"Кава з молоком",emoji:"🥛"},
  {id:11,name:"Лате 400 мл",price:75,category:"Кава з молоком",emoji:"🥛"},
  {id:12,name:"Флет-вайт 180–200 мл",price:65,category:"Кава з молоком",emoji:"☕"},
  {id:13,name:"Карамельне лате 300 мл",price:75,category:"Авторська кава",emoji:"🍮"},
  {id:14,name:"Ванільний раф 250 мл",price:75,category:"Авторська кава",emoji:"☕"},
  {id:15,name:"Лате білий шоколад 300 мл",price:80,category:"Авторська кава",emoji:"🍫"},
  {id:16,name:"Мокачино 300 мл",price:75,category:"Авторська кава",emoji:"🍫"},
  {id:17,name:"Какао 250 мл",price:50,category:"Какао та чай",emoji:"🍫"},
  {id:18,name:"Какао 350 мл",price:60,category:"Какао та чай",emoji:"🍫"},
  {id:19,name:"Чай чорний / зелений 300 мл",price:35,category:"Какао та чай",emoji:"🫖"},
  {id:20,name:"Чай лимон-імбир 300 мл",price:45,category:"Какао та чай",emoji:"🍋"},
  {id:21,name:"Лимонад класичний 300 мл",price:55,category:"Холодні напої",emoji:"🍋"},
  {id:22,name:"Лимонад ягідний 300 мл",price:60,category:"Холодні напої",emoji:"🍓"},
  {id:23,name:"Фрапе 300 мл",price:70,category:"Холодні напої",emoji:"🧋"},
  {id:24,name:"Молочний коктейль 400 мл",price:75,category:"Холодні напої",emoji:"🥤"},
  {id:25,name:"Смузі сезонний 300 мл",price:70,category:"Холодні напої",emoji:"🍹"},
  {id:26,name:"Холодний чай 300 мл",price:55,category:"Холодні напої",emoji:"🧊"},
  {id:27,name:"Круасан — 45 грн (базова ціна)",price:45,category:"Десерти",emoji:"🥐"},
  {id:28,name:"Печиво — 25 грн (базова ціна)",price:25,category:"Десерти",emoji:"🍪"},
  {id:29,name:"Маффін — 40 грн (базова ціна)",price:40,category:"Десерти",emoji:"🧁"},
  {id:30,name:"Батончик — 25 грн (базова ціна)",price:25,category:"Десерти",emoji:"🍫"},
  {id:31,name:"Комбо: Американо 200 мл + печиво",price:65,category:"Комбо",emoji:"☕"},
  {id:32,name:"Комбо: Капучино 200 мл + круасан",price:95,category:"Комбо",emoji:"🥐"},
  {id:33,name:"Комбо: Карамельне лате + маффін",price:110,category:"Комбо",emoji:"🍮"}
 ],
 ingredients:[
  {id:1,name:"Кавові зерна",qty:2000,unit:"г",min:500},
  {id:2,name:"Молоко",qty:5000,unit:"мл",min:1000},
  {id:3,name:"Стаканчики",qty:100,unit:"шт",min:20},
  {id:4,name:"Сироп",qty:1000,unit:"мл",min:200}
 ],
 recipes:[],orders:[],expenses:[]
};
let data=loadData(), cart={}, activeCategory='Усі';
const $=id=>document.getElementById(id);
function loadData(){try{return {...structuredClone(defaultData),...JSON.parse(localStorage.getItem(KEY)||'{}')}}catch(e){return structuredClone(defaultData)}}
function save(){localStorage.setItem(KEY,JSON.stringify(data));renderAll()}
function money(n){return new Intl.NumberFormat('uk-UA',{style:'currency',currency:'UAH',maximumFractionDigits:2}).format(n||0)}
function todayKey(d=new Date()){return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`}
function showToast(msg){$('toast').textContent=msg;$('toast').classList.add('show');setTimeout(()=>$('toast').classList.remove('show'),2500)}
function safe(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function setPage(page){document.querySelectorAll('.page').forEach(p=>p.classList.toggle('active',p.id==='page-'+page));document.querySelectorAll('.tab').forEach(t=>t.classList.toggle('active',t.dataset.page===page));if(page==='settings')renderMenuList()}
document.querySelectorAll('.tab').forEach(t=>t.addEventListener('click',()=>setPage(t.dataset.page)));
$('settingsShortcut').onclick=()=>setPage('settings');
$('todayLabel').textContent=new Intl.DateTimeFormat('uk-UA',{day:'numeric',month:'short'}).format(new Date());
function renderCategories(){let cats=['Усі',...new Set(data.products.map(p=>p.category))];$('categories').innerHTML=cats.map(c=>`<button class="category-btn ${activeCategory===c?'active':''}" data-cat="${safe(c)}">${safe(c)}</button>`).join('');document.querySelectorAll('[data-cat]').forEach(b=>b.onclick=()=>{activeCategory=b.dataset.cat;renderCategories();renderProducts()})}
function renderProducts(){let ps=data.products.filter(p=>activeCategory==='Усі'||p.category===activeCategory);$('products').innerHTML=ps.map(p=>`<button class="product-card" data-product="${p.id}"><div><div class="product-emoji">${safe(p.emoji||'☕')}</div><div class="product-name">${safe(p.name)}</div><div class="product-category">${safe(p.category)}</div></div><div class="product-price">${money(p.price)}</div></button>`).join('')||'<div class="empty-list">Додайте товари в розділі «Меню».</div>';document.querySelectorAll('[data-product]').forEach(b=>b.onclick=()=>{let id=+b.dataset.product;cart[id]=(cart[id]||0)+1;renderCart()})}
function renderCart(){let entries=Object.entries(cart).filter(([id,q])=>q>0);$('cartItems').innerHTML=entries.length?entries.map(([id,q])=>{let p=data.products.find(x=>x.id===+id);if(!p)return '';return `<div class="cart-line"><div><strong>${safe(p.name)}</strong><small>${money(p.price)} × ${q} = ${money(p.price*q)}</small></div><div class="qty-controls"><button data-minus="${id}">−</button><b>${q}</b><button data-plus="${id}">+</button></div></div>`}).join(''):'<p class="muted empty">Додайте товар до замовлення</p>';$('cartTotal').textContent=money(entries.reduce((s,[id,q])=>s+(data.products.find(p=>p.id===+id)?.price||0)*q,0));document.querySelectorAll('[data-minus]').forEach(b=>b.onclick=()=>{let id=b.dataset.minus;cart[id]--;if(cart[id]<=0)delete cart[id];renderCart()});document.querySelectorAll('[data-plus]').forEach(b=>b.onclick=()=>{let id=b.dataset.plus;cart[id]++;renderCart()})}
$('clearCart').onclick=()=>{cart={};renderCart()};
$('checkout').onclick=()=>{let entries=Object.entries(cart).filter(([id,q])=>q>0);if(!entries.length)return showToast('Спочатку додайте товар');let items=entries.map(([id,q])=>{let p=data.products.find(x=>x.id===+id);return {productId:p.id,name:p.name,qty:q,price:p.price}});let total=items.reduce((s,i)=>s+i.qty*i.price,0);data.orders.push({id:Date.now(),date:new Date().toISOString(),items,total,payment:$('paymentMethod').value});cart={};save();renderCart();showToast('Продаж збережено: '+money(total))};
function renderStock(){$('stockList').innerHTML=data.ingredients.length?data.ingredients.map(i=>`<div class="list-row"><div><strong>${safe(i.name)}</strong><small>Мінімальний залишок: ${i.min} ${safe(i.unit)}</small></div><div class="row-actions"><span style="font-weight:800;color:${i.qty<=i.min?'#9e3939':'#2e493c'}">${i.qty} ${safe(i.unit)}</span><button data-stock="${i.id}">Змінити</button></div></div>`).join(''):'<div class="empty-list">Склад поки порожній.</div>';document.querySelectorAll('[data-stock]').forEach(b=>b.onclick=()=>editIngredient(+b.dataset.stock))}
function renderFinance(){let key=todayKey();let sales=data.orders.filter(o=>o.date.slice(0,10)===key).reduce((s,o)=>s+o.total,0);let expenses=data.expenses.filter(e=>e.date===key).reduce((s,e)=>s+e.amount,0);$('finSales').textContent=money(sales);$('finExpenses').textContent=money(expenses);$('finNet').textContent=money(sales-expenses);$('expenseList').innerHTML=data.expenses.slice().reverse().slice(0,12).map(e=>`<div class="list-row"><div><strong>${safe(e.name)}</strong><small>${safe(e.date)}${e.note?' · '+safe(e.note):''}</small></div><strong>− ${money(e.amount)}</strong></div>`).join('')||'<div class="empty-list">Витрат ще немає.</div>'}
function renderReports(){let key=todayKey(),today=data.orders.filter(o=>o.date.slice(0,10)===key),weekStart=new Date();weekStart.setDate(weekStart.getDate()-6);weekStart.setHours(0,0,0,0);let week=data.orders.filter(o=>new Date(o.date)>=weekStart);$('repToday').textContent=money(today.reduce((s,o)=>s+o.total,0));$('repWeek').textContent=money(week.reduce((s,o)=>s+o.total,0));$('repOrders').textContent=today.length;let pop={};data.orders.forEach(o=>o.items.forEach(i=>pop[i.name]=(pop[i.name]||0)+i.qty));let rows=Object.entries(pop).sort((a,b)=>b[1]-a[1]).slice(0,10);$('popularList').innerHTML=rows.map(([n,q])=>`<div class="list-row"><strong>${safe(n)}</strong><strong>${q} шт.</strong></div>`).join('')||'<div class="empty-list">Продажі з’являться тут після перших замовлень.</div>'}
function renderMenuList(){$('menuList').innerHTML=data.products.map(p=>`<div class="list-row"><div><strong>${safe(p.emoji||'☕')} ${safe(p.name)}</strong><small>${safe(p.category)} · ${money(p.price)}</small></div><div class="row-actions"><button data-edit-product="${p.id}">Змінити</button><button data-del-product="${p.id}">×</button></div></div>`).join('')||'<div class="empty-list">Товарів немає.</div>';document.querySelectorAll('[data-edit-product]').forEach(b=>b.onclick=()=>editProduct(+b.dataset.editProduct));document.querySelectorAll('[data-del-product]').forEach(b=>b.onclick=()=>{let p=data.products.find(x=>x.id===+b.dataset.delProduct);if(p&&confirm(`Видалити «${p.name}»?`)){data.products=data.products.filter(x=>x.id!==p.id);save()}})}
function renderAll(){$('shopTitle').textContent=data.shopName||"Моя кав'ярня";$('shopNameInput').value=data.shopName||'';renderCategories();renderProducts();renderCart();renderStock();renderFinance();renderReports();renderMenuList()}
function modal(title,fields,handler){$('modalTitle').textContent=title;$('modalFields').innerHTML=fields.map(f=>`<div class="modal-field"><label for="f_${f.id}">${safe(f.label)}</label>${f.type==='select'?`<select id="f_${f.id}">${f.options.map(o=>`<option ${o===f.value?'selected':''}>${safe(o)}</option>`).join('')}</select>`:`<input id="f_${f.id}" type="${f.type||'text'}" ${f.step?'step="'+f.step+'"':''} ${f.min!==undefined?'min="'+f.min+'"':''} value="${safe(f.value??'')}" placeholder="${safe(f.placeholder||'')}" required>`}</div>`).join('');let dlg=$('formDialog');dlg.showModal();$('modalForm').onsubmit=e=>{if(e.submitter?.value!=='save')return;e.preventDefault();let values={};fields.forEach(f=>values[f.id]=$(('f_'+f.id)).value);if(handler(values)!==false)dlg.close()}}
function editProduct(id){let p=data.products.find(x=>x.id===id)||{name:'',price:'',category:'Кава',emoji:'☕'};modal(id?'Редагувати товар':'Новий товар',[{id:'name',label:'Назва',value:p.name},{id:'price',label:'Ціна, грн',type:'number',min:0,step:'0.01',value:p.price},{id:'category',label:'Категорія',type:'select',options:['Кава','Чай та інше','Десерти','Холодні напої','Інше'],value:p.category},{id:'emoji',label:'Емодзі товару',value:p.emoji||'☕'}],v=>{if(!v.name.trim()||!Number.isFinite(+v.price)||+v.price<0){showToast('Перевірте назву та ціну');return false}if(id)Object.assign(p,{name:v.name.trim(),price:+v.price,category:v.category,emoji:v.emoji||'☕'});else data.products.push({id:Date.now(),name:v.name.trim(),price:+v.price,category:v.category,emoji:v.emoji||'☕'});save()})}
$('addProductBtn').onclick=()=>editProduct(null);
function editIngredient(id){let i=data.ingredients.find(x=>x.id===id)||{name:'',qty:0,unit:'г',min:0};modal(id?'Змінити залишок':'Новий інгредієнт',[{id:'name',label:'Назва',value:i.name},{id:'qty',label:'Кількість',type:'number',min:0,value:i.qty},{id:'unit',label:'Одиниця (г, мл, шт)',value:i.unit},{id:'min',label:'Мінімальний залишок',type:'number',min:0,value:i.min}],v=>{if(!v.name.trim()||+v.qty<0||+v.min<0){showToast('Перевірте дані');return false}if(id)Object.assign(i,{name:v.name.trim(),qty:+v.qty,unit:v.unit,min:+v.min});else data.ingredients.push({id:Date.now(),name:v.name.trim(),qty:+v.qty,unit:v.unit,min:+v.min});save()})}
$('addIngredientBtn').onclick=()=>editIngredient(null);
$('addExpenseBtn').onclick=()=>modal('Додати витрату',[{id:'name',label:'На що витратили',value:''},{id:'amount',label:'Сума, грн',type:'number',min:0,step:'0.01',value:''},{id:'date',label:'Дата',type:'date',value:todayKey()},{id:'note',label:'Коментар (необов’язково)',value:''}],v=>{if(!v.name.trim()||!Number.isFinite(+v.amount)||+v.amount<=0){showToast('Вкажіть назву та суму');return false}data.expenses.push({id:Date.now(),name:v.name.trim(),amount:+v.amount,date:v.date||todayKey(),note:v.note});save()});
$('saveShopName').onclick=()=>{data.shopName=$('shopNameInput').value.trim()||"Моя кав'ярня";save();showToast('Назву збережено')};
$('backupBtn').onclick=()=>{let blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'});let a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='backup-kavyarnya.json';a.click();URL.revokeObjectURL(a.href)};
$('restoreBtn').onclick=()=>$('restoreFile').click();
$('restoreFile').onchange=async e=>{let file=e.target.files[0];if(!file)return;try{let obj=JSON.parse(await file.text());if(!obj.products||!obj.orders||!obj.ingredients)throw Error();data={...structuredClone(defaultData),...obj};save();showToast('Резервну копію відновлено')}catch(err){showToast('Не вдалося прочитати файл копії')}e.target.value=''};
$('resetBtn').onclick=()=>{if(confirm('Точно видалити всі дані цього застосунку? Спочатку зробіть резервну копію.')){data=structuredClone(defaultData);cart={};save();showToast('Дані скинуто')}};
$('exportCsv').onclick=()=>{let rows=[['Дата','Замовлення','Оплата','Товар','Кількість','Ціна','Сума']];data.orders.forEach(o=>o.items.forEach(i=>rows.push([o.date,o.id,o.payment,i.name,i.qty,i.price,i.qty*i.price])));let csv='\ufeff'+rows.map(r=>r.map(v=>'"'+String(v).replace(/"/g,'""')+'"').join(';')).join('\r\n');let a=document.createElement('a');a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8;'}));a.download='zvit-kavyarnya.csv';a.click();URL.revokeObjectURL(a.href)};
if('serviceWorker' in navigator && location.protocol.startsWith('http'))navigator.serviceWorker.register('./sw.js').catch(()=>{});
renderAll();